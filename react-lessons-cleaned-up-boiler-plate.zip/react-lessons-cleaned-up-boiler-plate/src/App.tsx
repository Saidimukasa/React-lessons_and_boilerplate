import React from 'react';
import './assets/css/App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <h1>Let us Learn React</h1>
      </header>
    </div>
  );
}

export default App;
